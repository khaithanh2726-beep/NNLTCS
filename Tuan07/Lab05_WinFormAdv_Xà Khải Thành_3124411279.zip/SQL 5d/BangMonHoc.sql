USE QLSinhVien;
SELECT * FROM MonHoc;